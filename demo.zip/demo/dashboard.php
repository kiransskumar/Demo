<?php

 
require('db.php');
include("auth.php"); //include auth.php file on all secure pages ?>
<div class="brand clearfix">
		<a href="#" class="logo" style="font-size:16px;">Students System</a>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			<li class="ts-account">
				<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><a href="admin-profile.php">My Account</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
	
<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			<p>Welcome to Dashboard.</p>
				
				<li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
					

				<li><a href="insert.php"><i class="fa fa-user"></i>Student Registration</a></li>
				<li><a href="view.php"><i class="fa fa-users"></i>Manage Students</a></li>
				

			
		</nav>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard - Secured Page</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p>Welcome to Dashboard.</p>

</div>
</body>
</html>
