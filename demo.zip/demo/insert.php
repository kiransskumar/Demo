<?php

 
require('db.php');
include("auth.php");


$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$trn_date = date("Y-m-d H:i:s");
$name =$_REQUEST['name'];
$age = $_REQUEST['age'];
$sex =$_REQUEST['sex'];
$education = $_REQUEST['education'];
$interest =$_REQUEST['interest'];

$submittedby = $_SESSION["username"];
$ins_query="insert into new_record (`trn_date`,`name`,`age`,`sex`,`education`,`interest`,`submittedby`) values ('$trn_date','$name','$age','$sex','$education','$interest','$submittedby')";
mysqli_query($con,$ins_query) or die(mysql_error());
$status = "New Record Inserted Successfully.</br></br><a href='view.php'>View Inserted Record</a>";
}
?>
<div class="brand clearfix">
		<a href="#" class="logo" style="font-size:16px;">Students System</a>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			<li class="ts-account">
				<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><a href="admin-profile.php">My Account</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
	
<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			<p>Welcome to Dashboard.</p>
				
				<li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
								<li><a href="insert.php"><i class="fa fa-user"></i>Student Registration</a></li>
				<li><a href="view.php"><i class="fa fa-users"></i>Manage Students</a></li>
				

			
		</nav>
<!DOCTYPE html>
<html>

<head> 
  <title>Bootstrap Example</title> 
  <meta charset="utf-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script> 
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> 
</head> 
<body>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> | <a href="view.php">View Records</a> | <a href="logout.php">Logout</a></p>
<div class="container"> 
    <h4>Insert New Record</h4> 
    <br> 
  <form class="form-inline" action="/action_page.php"> 
    <label for="text">Enter name:</label> 
    <input type="text" class="form-control" name="name" placeholder="Enter Name" required />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    
	<label for="text">Enter Age:</label> 
    <input type="text" class="form-control"  name="age" placeholder="Enter Age" required />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<label for="text">Enter Sex:</label> 
    <input type="text" class="form-control"  name="sex" placeholder="Enter Sex" required /><br/><br/><br/>
	<label for="text">Enter Age:</label> 
    <input type="text" class="form-control"  name="sex" placeholder="Enter Sex" required />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<label for="text">Enter Education:</label> 
    <input type="text" class="form-control"  name="education" placeholder="Enter Education" required />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<label for="text">Enter Interest:</label> 
    <input type="text" class="form-control"  name="interest" placeholder="Enter Area of Interest" required /><br/><br/>
	<input name="submit" type="submit" value="Submit" /></p>
    
  </form> 
  <p style="color:#FF0000;"><?php echo $status; ?></p>
      
</div> 


</div>
</body>
</html>
